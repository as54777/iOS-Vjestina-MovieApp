import UIKit
import PureLayout
import MovieAppData

class MovieDetailsViewController: UIViewController {
    
    private var usernameTextField: UITextField!
    private var passwordTextField: UITextField!
    private var loginButton: UIButton!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        usernameTextField = UITextField.newAutoLayout()
        usernameTextField.borderStyle = .roundedRect
        usernameTextField.placeholder = "Username"
        
        passwordTextField = UITextField.newAutoLayout()
        passwordTextField.borderStyle = .roundedRect
        passwordTextField.placeholder = "Password"
        passwordTextField.isSecureTextEntry = true
        
        loginButton = UIButton(type: .system)
        loginButton.setTitle("Login", for: .normal)
        loginButton.setTitleColor(.white, for: .normal)
        loginButton.backgroundColor = .green
        
        // Dodavanje u view
        view.addSubview(usernameTextField)
        view.addSubview(passwordTextField)
        view.addSubview(loginButton)
        
        // Postavljanje Auto Layout ograničenja pomoću PureLayout-a
        usernameTextField.autoAlignAxis(toSuperviewAxis: .vertical)
        usernameTextField.autoPinEdge(toSuperviewEdge: .top, withInset: 120)
        usernameTextField.autoSetDimensions(to: CGSize(width: 200, height: 40))
        
        passwordTextField.autoAlignAxis(toSuperviewAxis: .vertical)
        passwordTextField.autoPinEdge(.top, to: .bottom, of: usernameTextField, withOffset: 20)
        passwordTextField.autoSetDimensions(to: CGSize(width: 200, height: 40))
        
        loginButton.autoAlignAxis(toSuperviewAxis: .vertical)
        loginButton.autoPinEdge(.top, to: .bottom, of: passwordTextField, withOffset: 20)
        loginButton.autoSetDimensions(to: CGSize(width: 200, height: 40))
        
        loginButton.addTarget(self, action: #selector(loginButtonTapped), for: .touchUpInside)
    }
    
    @objc private func loginButtonTapped() {
        let detailsVC = DetailsView()
        present(detailsVC, animated: true, completion: nil)
    }
    
    let movieDetails = MovieUseCase().getDetails(id: 111161)
    
}

class DetailsView: UIViewController {
    let RatingLabel = UILabel()
    let Userscore = UILabel()
    let MovieNameLabel = UILabel()
    let YearLabel = UILabel()
    let DateLabel = UILabel()
    let MovieDurationLabel = UILabel()
    let CategoryLabel = UILabel()
    let OverviewLabel = UILabel()
    let MovieSummaryLabel = UILabel()
    
    let ScreenView1 = UIView()
    let ScreenView2 = UIView()
    
    weak var collectionView: UICollectionView!
    
    var  allMembers: [String] = []
    var  allRoles: [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        
        let stackView = UIStackView()
        
        stackView.addArrangedSubview(ScreenView1)
        
        stackView.addArrangedSubview(ScreenView2)
        
        stackView.axis = .vertical
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        
        view.addSubview(stackView)
        stackView.autoPinEdgesToSuperviewEdges()
        
        let movieDetails = MovieUseCase().getDetails(id: 111161)
        print("Informacije o filmu: \(movieDetails)")
        
        let movieImageView = UIImageView()
        movieImageView.contentMode = .scaleAspectFill
        movieImageView.clipsToBounds = true
        if let url = URL(string: "https://m.media-amazon.com/images/M/MV5BMDFkYTc0MGEtZmNhMC00ZDIzLWFmNTEtODM1ZmRlYWMwMWFmXkEyXkFqcGdeQXVyMTMxODk2OTU@._V1_QL75_UX380_CR0,1,380,562_.jpg"),
           let data = try? Data(contentsOf: url),
           let image = UIImage(data: data) {
            movieImageView.image = image
        }
        ScreenView1.addSubview(movieImageView)
        movieImageView.autoPinEdgesToSuperviewSafeArea()
        
        if let movieRating = movieDetails?.rating {
            RatingLabel.text = String(movieRating)
            RatingLabel.textColor = .white
            RatingLabel.font = UIFont.boldSystemFont(ofSize: 20)
            ScreenView1.addSubview(RatingLabel)
            RatingLabel.autoPinEdge(.top, to: .top, of: movieImageView, withOffset: 100)
            RatingLabel.autoPinEdge(.leading, to: .leading, of: view, withOffset: 30)
        }
        
        Userscore.text = "User Score"
        Userscore.textColor = .white
        ScreenView1.addSubview(Userscore)
        Userscore.autoPinEdge(.top, to: .bottom, of: RatingLabel, withOffset: -23)
        Userscore.autoPinEdge(.leading, to: .trailing, of: RatingLabel, withOffset: 5)
        
        MovieNameLabel.text = movieDetails?.name
        MovieNameLabel.textColor = .white
        MovieNameLabel.font = UIFont.boldSystemFont(ofSize: 22)
        ScreenView1.addSubview(MovieNameLabel)
        MovieNameLabel.autoPinEdge(.top, to: .bottom, of: Userscore, withOffset: 10)
        MovieNameLabel.autoPinEdge(.leading, to: .leading, of: view, withOffset: 30)
        
        if let year = movieDetails?.year {
            YearLabel.text = "(\(String(year)))"
            YearLabel.textColor = .white
            ScreenView1.addSubview(YearLabel)
            YearLabel.autoPinEdge(.top, to: .top, of: MovieNameLabel, withOffset: 3)
            YearLabel.autoPinEdge(.leading, to: .trailing, of: MovieNameLabel, withOffset: 5)
        }
        
        if let MovieDate = movieDetails?.releaseDate {
            let MovieDateComponents = MovieDate.components(separatedBy: "-")
            if MovieDateComponents.count == 3 {
                let MovieYear = MovieDateComponents[0].trimmingCharacters(in: .whitespaces)
                var MovieMonth = MovieDateComponents[1].trimmingCharacters(in: .whitespaces)
                if MovieMonth.count == 1 {
                    MovieMonth = "0" + MovieMonth
                }
                var MovieDay = MovieDateComponents[2].trimmingCharacters(in: .whitespaces)
                if MovieDay.count == 1 {
                    MovieDay = "0" + MovieDay
                }
                let formattedDateString = "\(MovieMonth)/\(MovieDay)/\(MovieYear)(US)"
                DateLabel.text = formattedDateString
                DateLabel.textColor = .white
                ScreenView1.addSubview(DateLabel)
                DateLabel.autoPinEdge(.top, to: .bottom, of: MovieNameLabel, withOffset: 50)
                DateLabel.autoPinEdge(.leading, to: .leading, of: view, withOffset: 30)
            }
        }
        
        CategoryLabel.text = "Drama"
        CategoryLabel.textColor = .white
        ScreenView1.addSubview(CategoryLabel)
        CategoryLabel.autoPinEdge(.top, to: .bottom, of: DateLabel, withOffset: 10)
        CategoryLabel.autoPinEdge(.leading, to: .leading, of: view, withOffset: 30)
        
        if var duration = movieDetails?.duration {
            let MovieDurationHour = duration / 60
            let MovieDurationMinutes = duration % 60
            MovieDurationLabel.text = "\(MovieDurationHour)h \(MovieDurationMinutes)m"
            MovieDurationLabel.textColor = .white
            MovieDurationLabel.font = UIFont.boldSystemFont(ofSize: 16)
            ScreenView1.addSubview(MovieDurationLabel)
            MovieDurationLabel.autoPinEdge(.top, to: .bottom, of: CategoryLabel, withOffset: -20)
            MovieDurationLabel.autoPinEdge(.leading, to: .trailing, of: CategoryLabel, withOffset: 10)
        }
        
        OverviewLabel.text = "Overview"
        OverviewLabel.textColor = .black
        OverviewLabel.font = UIFont.boldSystemFont(ofSize: 24)
        ScreenView2.addSubview(OverviewLabel)
        OverviewLabel.autoPinEdge(.top, to: .bottom, of: movieImageView, withOffset: 20)
        OverviewLabel.autoPinEdge(.leading, to: .leading, of: view, withOffset: 30)
        
        MovieSummaryLabel.text = movieDetails?.summary
        MovieSummaryLabel.textColor = .black
        MovieSummaryLabel.numberOfLines = 0
        MovieSummaryLabel.lineBreakMode = .byWordWrapping
        ScreenView2.addSubview(MovieSummaryLabel)
        MovieSummaryLabel.autoPinEdge(.top, to: .bottom, of: OverviewLabel, withOffset: 10)
        MovieSummaryLabel.autoPinEdge(.leading, to: .leading, of: view, withOffset: 30)
        let labelWidth = view.frame.width - 60
        let labelSize = (movieDetails?.summary ?? "").boundingRect(with: CGSize(width: labelWidth, height: CGFloat.greatestFiniteMagnitude), options: .usesLineFragmentOrigin, attributes: [.font: MovieSummaryLabel.font!], context: nil).size
        MovieSummaryLabel.autoSetDimensions(to: labelSize)
        
        if let crewMembers = movieDetails?.crewMembers {
            for member in crewMembers {
                allMembers.append("\(member.name)")
            }
        }

        if let crewMembers = movieDetails?.crewMembers {
            for member in crewMembers {
                allRoles.append("\(member.role)")
            }
        }
        
        let MemberLabel1 = UILabel()
        MemberLabel1.text = allMembers[0]
        MemberLabel1.textColor = .black
        MemberLabel1.font = UIFont.boldSystemFont(ofSize: 14)
        ScreenView2.addSubview(MemberLabel1)
        MemberLabel1.autoPinEdge(.top, to: .bottom, of: MovieSummaryLabel, withOffset: 20)
        MemberLabel1.autoPinEdge(.leading, to: .leading, of: view, withOffset: 30)
        
        let MemberLabel2 = UILabel()
        MemberLabel2.text = allMembers[1]
        MemberLabel2.font = UIFont.boldSystemFont(ofSize: 14)
        MemberLabel2.textColor = .black
        ScreenView2.addSubview(MemberLabel2)
        MemberLabel2.autoPinEdge(.top, to: .top, of: MemberLabel1)
        MemberLabel2.autoPinEdge(.leading, to: .trailing, of: MemberLabel1, withOffset: 20)
        
        let MemberLabel3 = UILabel()
        MemberLabel3.text = allMembers[2]
        MemberLabel3.font = UIFont.boldSystemFont(ofSize: 14)
        MemberLabel3.textColor = .black
        ScreenView2.addSubview(MemberLabel3)
        MemberLabel3.autoPinEdge(.top, to: .top, of: MemberLabel2)
        MemberLabel3.autoPinEdge(.leading, to: .trailing, of: MemberLabel2, withOffset: 20)
        
        let Role1 = UILabel()
        Role1.text = allRoles[0]
        Role1.textColor = .black
        Role1.font = UIFont.systemFont(ofSize: 14)
        ScreenView2.addSubview(Role1)
        Role1.autoPinEdge(.top, to: .bottom, of: MemberLabel1, withOffset: 10)
        Role1.autoPinEdge(.leading, to: .leading, of: MemberLabel1)
        
        let Role2 = UILabel()
        Role2.text = allRoles[1]
        Role2.textColor = .black
        Role2.font = UIFont.systemFont(ofSize: 14)
        ScreenView2.addSubview(Role2)
        Role2.autoPinEdge(.top, to: .bottom, of: MemberLabel2, withOffset: 10)
        Role2.autoPinEdge(.leading, to: .leading, of: MemberLabel2)
        
        let Role3 = UILabel()
        Role3.text = allRoles[2]
        Role3.textColor = .black
        Role3.font = UIFont.systemFont(ofSize: 14)
        ScreenView2.addSubview(Role3)
        Role3.autoPinEdge(.top, to: .bottom, of: MemberLabel3, withOffset: 10)
        Role3.autoPinEdge(.leading, to: .leading, of: MemberLabel3)
        
        let MemberLabel4 = UILabel()
        MemberLabel4.text = allMembers[3]
        MemberLabel4.textColor = .black
        MemberLabel4.font = UIFont.boldSystemFont(ofSize: 14)
        ScreenView2.addSubview(MemberLabel4)
        MemberLabel4.autoPinEdge(.top, to: .bottom, of: Role1, withOffset: 20)
        MemberLabel4.autoPinEdge(.leading, to: .leading, of: Role1)
        
        let MemberLabel5 = UILabel()
        MemberLabel5.text = allMembers[4]
        MemberLabel5.font = UIFont.boldSystemFont(ofSize: 14)
        MemberLabel5.textColor = .black
        ScreenView2.addSubview(MemberLabel5)
        MemberLabel5.autoPinEdge(.top, to: .top, of: MemberLabel4)
        MemberLabel5.autoPinEdge(.leading, to: .trailing, of: MemberLabel4, withOffset: 20)
        
        let Role4 = UILabel()
        Role4.text = allRoles[3]
        Role4.textColor = .black
        Role4.font = UIFont.systemFont(ofSize: 14)
        ScreenView2.addSubview(Role4)
        Role4.autoPinEdge(.top, to: .bottom, of: MemberLabel4, withOffset: 10)
        Role4.autoPinEdge(.leading, to: .leading, of: MemberLabel4)
        
        let Role5 = UILabel()
        Role5.text = allRoles[4]
        Role5.textColor = .black
        Role5.font = UIFont.systemFont(ofSize: 14)
        ScreenView2.addSubview(Role5)
        Role5.autoPinEdge(.top, to: .bottom, of: MemberLabel5, withOffset: 10)
        Role5.autoPinEdge(.leading, to: .leading, of: MemberLabel5)
        
        
        
    }

}
